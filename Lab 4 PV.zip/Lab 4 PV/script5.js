
function onEnterPressed(event){
    if(event.key !== "Enter"){
        return;
    }

    addEntry();
}

var id=0;

function addEntry() {
    snippet = `
    <tr id="${id}">
        <td onClick="removeEntry(${id})"}>❌</td>
        <td>${getName()}</td>
    </tr>
    `
    id +=1;
    setName("");
    
    document.getElementById("tbody").innerHTML += snippet;
}

function removeEntry(id) {
    document.getElementById(id).remove();
}

/**
 * Getting an  array of cars and adding that to the table with the refresh function.
 */
var cars=["BMW","Elantra","Sentafe","Creta"];
function refreshTable() {
    
    var i,code="";
    for (i = 0; i < cars.length; i++) {
        var row="<tr>"+"<td>"+"❌"+ "</td>"+"<td>"+ cars[i]+ "</td>"+"</tr>";
        code += row + "\n";
    }
    document.getElementById("tbody").innerHTML =code;

    snippet = `
    <tr id="${id}">
        <td onClick="removeEntry(${id})"}>❌</td>
        <td>${getName()}</td>
    </tr>
    `
    id +=1;
    setName("");
    
    document.getElementById("tbody").innerHTML += snippet;

   

}



function getName() {
    
    
    return document.getElementById("name").innerHTML=name;
}

function setName(name) {
    return document.getElementById("name").value=name;
}
